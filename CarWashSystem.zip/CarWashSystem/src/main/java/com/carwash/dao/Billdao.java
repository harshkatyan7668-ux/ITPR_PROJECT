package com.carwash.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.Statement;
import com.carwash.model.Bill;
import com.carwash.util.DBConnection;
import java.util.ArrayList;
import java.util.List;

public class Billdao {

    private Connection getCon() {
        return DBConnection.getConnection();
    }

    public Bill generateBill(int customerId, String carModel, String packageName) {
        try {
            Connection con = getCon();

            // 1. Find car ID
            PreparedStatement psCar = con.prepareStatement(
                "SELECT car_id FROM cars WHERE customer_id = ? AND car_model = ? LIMIT 1"
            );
            psCar.setInt(1, customerId);
            psCar.setString(2, carModel);
            ResultSet rsCar = psCar.executeQuery();

            int carId;
            if (rsCar.next()) {
                carId = rsCar.getInt("car_id");
            } else {
                System.out.println("❌ Car not found for this customer!");
                return null;
            }

            // 2. Find package ID + price
            PreparedStatement psPkg = con.prepareStatement(
                "SELECT package_id, price FROM packages WHERE package_name = ? LIMIT 1"
            );
            psPkg.setString(1, packageName);
            ResultSet rsPkg = psPkg.executeQuery();

            int packageId;
            double price;
            if (rsPkg.next()) {
                packageId = rsPkg.getInt("package_id");
                price = rsPkg.getDouble("price");
            } else {
                System.out.println("❌ Package not found!");
                return null;
            }

            // 3. Insert into bills
            PreparedStatement psInsert = con.prepareStatement(
                "INSERT INTO bills(customer_id, car_id, package_id, amount) VALUES(?,?,?,?)",
                Statement.RETURN_GENERATED_KEYS
            );
            psInsert.setInt(1, customerId);
            psInsert.setInt(2, carId);
            psInsert.setInt(3, packageId);
            psInsert.setDouble(4, price);

            int rows = psInsert.executeUpdate();
            if (rows == 0) {
                return null;
            }

            // 4. Fetch bill ID
            ResultSet rsKeys = psInsert.getGeneratedKeys();
            int billId = -1;
            if (rsKeys.next()) {
                billId = rsKeys.getInt(1);
            }

            return new Bill(billId, customerId, carId, packageId, price);

        } catch (Exception e) {
            e.printStackTrace();
            return null;
        }
    }

    public List<Bill> getAllBills() {
        List<Bill> list = new ArrayList<>();
        try {
            Connection con = getCon();
            PreparedStatement ps = con.prepareStatement("SELECT * FROM bills");
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Bill b = new Bill(
                    rs.getInt("bill_id"),
                    rs.getInt("customer_id"),
                    rs.getInt("car_id"),
                    rs.getInt("package_id"),
                    rs.getDouble("amount")
                );
                list.add(b);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }
        return list;
    }
}
