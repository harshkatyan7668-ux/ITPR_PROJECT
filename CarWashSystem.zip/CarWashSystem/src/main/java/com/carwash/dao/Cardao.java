package com.carwash.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.carwash.model.Car;
import com.carwash.util.DBConnection;

public class Cardao {

    // Add Car
    public boolean addCar(Car car) {
        boolean status = false;

        try {
            Connection con = DBConnection.getConnection();
            String sql = "INSERT INTO cars (customer_id, car_number, car_model) VALUES (?, ?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setInt(1, car.getCustomerId());
            ps.setString(2, car.getCarNumber());
            ps.setString(3, car.getCarModel());

            int row = ps.executeUpdate();
            if (row > 0) {
                status = true;
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return status;
    }

    // Get All Cars
    public List<Car> getAllCars() {
        List<Car> list = new ArrayList<>();

        try {
            Connection con = DBConnection.getConnection();
            String sql = "SELECT * FROM cars";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Car c = new Car();
                c.setCarId(rs.getInt("car_id"));
                c.setCustomerId(rs.getInt("customer_id"));
                c.setCarNumber(rs.getString("car_number"));
                c.setCarModel(rs.getString("car_model"));

                list.add(c);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}
