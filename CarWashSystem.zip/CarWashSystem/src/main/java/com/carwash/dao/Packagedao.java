package com.carwash.dao;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

import com.carwash.model.Package;
import com.carwash.util.DBConnection;

public class Packagedao {

    // ADD PACKAGE
    public boolean addPackage(Package p) {
        boolean status = false;

        try {
            Connection con = DBConnection.getConnection();
            String sql = "INSERT INTO packages (package_name, price) VALUES (?, ?)";
            PreparedStatement ps = con.prepareStatement(sql);

            ps.setString(1, p.getPackageName());
            ps.setDouble(2, p.getPrice());

            int row = ps.executeUpdate();
            if (row > 0) status = true;

        } catch (Exception e) {
            e.printStackTrace();
        }

        return status;
    }

    // VIEW ALL PACKAGES
    public List<Package> getAllPackages() {
        List<Package> list = new ArrayList<>();

        try {
            Connection con = DBConnection.getConnection();
            String sql = "SELECT * FROM packages";
            PreparedStatement ps = con.prepareStatement(sql);
            ResultSet rs = ps.executeQuery();

            while (rs.next()) {
                Package p = new Package();
                p.setPackageId(rs.getInt("package_id"));
                p.setPackageName(rs.getString("package_name"));
                p.setPrice(rs.getDouble("price"));

                list.add(p);
            }

        } catch (Exception e) {
            e.printStackTrace();
        }

        return list;
    }
}
