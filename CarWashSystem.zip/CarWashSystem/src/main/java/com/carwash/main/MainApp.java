package com.carwash.main;

import java.util.List;
import java.util.Scanner;

import com.carwash.dao.Customerdao;
import com.carwash.dao.Cardao;
import com.carwash.dao.Packagedao;
import com.carwash.dao.Billdao;
import com.carwash.model.Customer;
import com.carwash.model.Car;
import com.carwash.model.Package;
import com.carwash.model.Bill;

public class MainApp {

    public static void main(String[] args) {

        Scanner sc = new Scanner(System.in);

        Customerdao dao = new Customerdao();
        Cardao cdao = new Cardao();
        Packagedao pdao = new Packagedao();
        Billdao bdao = new Billdao();   // NEW DAO

        while (true) {

            System.out.println("\n==== CAR WASH MENU ====");
            System.out.println("1. Add Customer");
            System.out.println("2. View All Customers");
            System.out.println("3. Exit");
            System.out.println("4. Add Car");
            System.out.println("5. View All Cars");
            System.out.println("6. Add Wash Package");
            System.out.println("7. View All Packages");
            System.out.println("8. Generate Bill");       // NEW
            System.out.println("9. View All Bills");      // NEW

            System.out.print("Enter choice: ");

            int choice = sc.nextInt();
            sc.nextLine(); 

            switch (choice) {

                case 1:
                    System.out.print("Enter name: ");
                    String name = sc.nextLine();

                    System.out.print("Enter phone: ");
                    String phone = sc.nextLine();

                    System.out.print("Enter email: ");
                    String email = sc.nextLine();

                    Customer customer = new Customer(name, phone, email);

                    if (dao.addCustomer(customer)) {
                        System.out.println("Customer Added Successfully!");
                    } else {
                        System.out.println("Failed to add customer.");
                    }
                    break;

                case 2:
                    List<Customer> list = dao.getAllCustomers();
                    System.out.println("\n---- Customer List ----");
                    for (Customer cu : list) {
                        System.out.println(
                            cu.getCustomerId() + " | " +
                            cu.getName() + " | " +
                            cu.getPhone() + " | " +
                            cu.getEmail()
                        );
                    }
                    break;

                case 3:
                    System.out.println("Exiting...");
                    System.exit(0);
                    break;

                case 4:
                    System.out.print("Enter Customer ID: ");
                    int cid = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Enter Car Number: ");
                    String number = sc.nextLine();

                    System.out.print("Enter Car Model: ");
                    String model = sc.nextLine();

                    Car car = new Car(cid, number, model);

                    if (cdao.addCar(car)) {
                        System.out.println("Car Added Successfully!");
                    } else {
                        System.out.println("Failed to add car.");
                    }
                    break;

                case 5:
                    List<Car> cars = cdao.getAllCars();
                    System.out.println("\n---- Car List ----");
                    for (Car carObj : cars) {
                        System.out.println(
                            carObj.getCarId() + " | " +
                            carObj.getCustomerId() + " | " +
                            carObj.getCarNumber() + " | " +
                            carObj.getCarModel()
                        );
                    }
                    break;

                case 6:
                    System.out.print("Enter Package Name: ");
                    String pname = sc.nextLine();

                    System.out.print("Enter Price: ");
                    double price = sc.nextDouble();
                    sc.nextLine();

                    Package p = new Package(pname, price);

                    if (pdao.addPackage(p)) {
                        System.out.println("Package Added Successfully!");
                    } else {
                        System.out.println("Failed to add package.");
                    }
                    break;

                case 7:
                    List<Package> pkgs = pdao.getAllPackages();
                    System.out.println("\n---- Package List ----");

                    for (Package pp : pkgs) {
                        System.out.println(
                            pp.getPackageId() + " | " +
                            pp.getPackageName() + " | " +
                            pp.getPrice()
                        );
                    }
                    break;

                // -------------------------------
                //        BILL MODULE
                // -------------------------------

                case 8:
                    System.out.print("Enter Customer ID: ");
                    int bcust = sc.nextInt();
                    sc.nextLine();

                    System.out.print("Enter Car Model: ");
                    String bmodel = sc.nextLine();

                    System.out.print("Enter Package Name: ");
                    String bpackage = sc.nextLine();

                    Bill bill = bdao.generateBill(bcust, bmodel, bpackage);

                    if (bill != null) {
                        System.out.println("\n---- BILL GENERATED ----");
                        System.out.println("Bill ID: " + bill.getBillId());
                        System.out.println("Customer ID: " + bill.getCustomerId());
                        System.out.println("Car Model: " + bmodel);
                        System.out.println("Package: " + bpackage);
                        System.out.println("Amount: " + bill.getAmount());
                    } else {
                        System.out.println("Failed to generate bill!");
                    }
                    break;

                case 9:
                    List<Bill> bills = bdao.getAllBills();
                    System.out.println("\n---- ALL BILLS ----");
                    for (Bill bb : bills) {
                        System.out.println(
                            bb.getBillId() + " | " +
                            bb.getCustomerId() + " | " +
                            bb.getCarId() + " | " +
                            bb.getPackageId() + " | " +
                            bb.getAmount()
                        );
                    }
                    break;

                default:
                    System.out.println("Invalid choice!");
            }
        }
    }
}
