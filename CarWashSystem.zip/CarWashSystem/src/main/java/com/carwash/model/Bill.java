package com.carwash.model;

public class Bill {

    private int billId;
    private int customerId;
    private int carId;
    private int packageId;
    private double amount;

    public Bill(int billId, int customerId, int carId, int packageId, double amount) {
        this.billId = billId;
        this.customerId = customerId;
        this.carId = carId;
        this.packageId = packageId;
        this.amount = amount;
    }

    public int getBillId() {
        return billId;
    }

    public int getCustomerId() {
        return customerId;
    }

    public int getCarId() {
        return carId;
    }

    public int getPackageId() {
        return packageId;
    }

    public double getAmount() {
        return amount;
    }
}
